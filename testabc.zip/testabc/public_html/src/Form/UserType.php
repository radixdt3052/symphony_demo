<?php

namespace App\Form;

use App\Entity\User;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\BirthdayType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints as Assert;

class UserType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        // $builder
        //     ->add('name', TextType::class, [
        //         'constraints' => [
        //             new Assert\NotBlank([
        //                 'message' => 'Please enter your name.',
        //             ]),
        //         ],
        //     ])
        //     ->add('age', IntegerType::class, [
        //         'constraints' => [
        //             new Assert\NotBlank([
        //                 'message' => 'Please enter your age.',
        //             ]),
        //             new Assert\GreaterThan([
        //                 'value' => 0,
        //                 'message' => 'Age must be greater than 0.',
        //             ]),
        //         ],
        //     ])
        //     
        //     ->add('gender', ChoiceType::class, [
        //         'choices' => [
        //             'Male' => 'Male',
        //             'Female' => 'Female',
        //             'Other' => 'Other',
        //         ],
        //         'expanded' => true,
        //         'constraints' => [
        //             new Assert\NotBlank([
        //                 'message' => 'Please select your gender.',
        //             ]),
        //         ],
        //     ])
        //     ->add('email', EmailType::class, [
        //         'constraints' => [
        //             new Assert\NotBlank([
        //                 'message' => 'Please enter your email address.',
        //             ]),
        //             new Assert\Email([
        //                 'message' => 'Please enter a valid email address.',
        //             ]),
        //         ],
        //     ])
        //     ->add('save', SubmitType::class, [
        //         'label' => 'Save',
        //         'attr' => ['class' => 'btn btn-primary'],
        //     ]);

        $builder
        ->add('name', TextType::class, [
                'required' => false, 
            ])
            ->add('email', EmailType::class, [
                'required' => false, 
            ])
            ->add('gender', ChoiceType::class, [
                'choices' => [
                    'Male' => 'Male',
                    'Female' => 'Female'
                ],
                'required' => false,
            ])
            ->add('age', IntegerType::class, [
                'required' => false,
                'invalid_message' => 'Age should be a valid number',
            ])
            ->add('save', SubmitType::class, [
                'label' => 'Save',
                'attr' => ['class' => 'btn btn-primary'],
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => User::class,
        ]);
    }
}
