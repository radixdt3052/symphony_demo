<?php

namespace App\Form;

use App\Entity\Product;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\ButtonType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;  
use App\Entity\Category;
use Doctrine\ORM\EntityManagerInterface;

class ProductType extends AbstractType
{
    private $transformer;
    private $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }
    
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $categories = $this->entityManager->getRepository(Category::class)->findAllCategories();

        $choices = [];
        foreach ($categories as $category) {
            $choices[$category->getCategoryName()] = $category->getId();
            // echo $category->getId();
        }
        $builder
            ->add('productName', TextType::class, [
                'label' => 'Product Name',
            ])
            ->add('price', NumberType::class, [
                'label' => 'Price',
                'scale' => 2, // Optional: Limits decimals to 2 places
            ])
            ->add('description', TextType::class, [
                'label' => 'Description',
            ])
            ->add('categoryId', ChoiceType::class, [
                'choices' => $choices,
                'placeholder' => 'Choose a category',
                'required' => true,
                'label' => 'Select Category  : ',
            ])
            ->add('save', SubmitType::class, [
                'label' => 'Update Product',
                'attr' => ['class' => 'btn btn-primary'],
            ])
            ->add('back', ButtonType::class, [
                'label' => 'Back',
                'attr' => ['class' => 'btn btn-secondary', 'onclick' => 'history.back();'],
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Product::class,
            'csrf_protection' => true,
        ]);
    }
}
