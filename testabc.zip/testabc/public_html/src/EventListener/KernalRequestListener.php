<?php


namespace App\EventListener;

use Psr\Log\LoggerInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\KernelEvents;

class KernalRequestListener
{
    private $logger;

    public function __construct(LoggerInterface $logger)
    {
        $this->logger = $logger;
    }
    // public static function getSubscribedEvents()
    // {
    //     return [
    //         KernelEvents::REQUEST => ['onKernelRequest',11]
    //     ];
    // }

    public function onKernelRequest(RequestEvent $event)
    {
        $request = $event->getRequest();
        $uri = $request->getUri();
        $this->logger->info("Kernal Request Listener: $uri");
    }
}
