<?php


namespace App;

use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpFoundation\Response;
use Psr\Log\LoggerInterface;

class IPWhitelistListenerss
{
    private array $whitelistedIPs;
    private LoggerInterface $logger;

    public function __construct(array $whitelistedIPs, LoggerInterface $logger)
    {
        $this->whitelistedIPs = $whitelistedIPs;
        $this->logger = $logger;
    }

    public function onKernelRequest(RequestEvent $event)
    {
        $request = $event->getRequest();
        $ip = $request->getClientIp();
        // Check if the requesting IP is in the whitelist
        if (!in_array($ip, $this->whitelistedIPs)) {
            $this->logger->notice(sprintf('Access denied for IP: %s', $ip));
        }
    }
}
