<?php

namespace App\Controller;

use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;
use Doctrine\ORM\EntityManagerInterface;
use App\Repository\CategoryRepository;
use App\Repository\ProductRepository;
use App\Entity\Product;
use App\Form\ProductType;
use App\Form\ProductAddType;

class ProductController extends AbstractController
{
    #[Route('/product', name: 'list_product')]
    public function index(ProductRepository $productRepository): Response
    {
        $products = $productRepository->findAll();
        foreach ($products as $product) {
            $categoryName = $product->getCategory()->getCategoryName();
            $product->categoryName = $categoryName;
        }
        return $this->render('product/list.html.twig', [
            'products' => $products,
        ]);
    }


    #[Route('/add',name:'product_add')]
    public function insert(Request $request, EntityManagerInterface $entityManager,CategoryRepository $categoryRepository){
        $product = new Product();
        $form = $this->createForm(ProductAddType::class, $product);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $id = $form->get('categoryId')->getData();
            $category = $categoryRepository->find($id);
            $product->setCategory($category);
            $entityManager->persist($product);
            $entityManager->flush();
            $this->addFlash('success', 'Product added successfully.');
            return $this->redirectToRoute('list_product');
        }
        return $this->render('product/add.html.twig', [
            'form' => $form->createView(),
        ]);
    }


    #[Route('/edit', name: 'edit_product', methods: ['GET', 'POST'])]
    public function edit_product(Request $request,EntityManagerInterface $entityManager,ProductRepository $productRepository, Product $product) : Response   {
        $id = $request->query->get('id');
        if (!$id) {
            throw $this->createNotFoundException('Product ID not found');
        }
        $product = $productRepository->find($id);
        $form = $this->createForm(ProductType::class, $product);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();

            return $this->redirectToRoute('list_product');
        }
        return $this->render('product/edit.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    #[Route('/delete', name: 'delete_product', methods: ['GET'])]
    public function delete_product(EntityManagerInterface $entityManager,ProductRepository $productRepository,Request $request){
        $id = $request->query->get('id');
        if (!$id) {
            throw $this->createNotFoundException('Product ID not found');
        }
        $product = $productRepository->find($id);
        if (!$product) {
            throw $this->createNotFoundException('No product found for id '.$id);
        }
        // print('here');
        $entityManager->remove($product);
        $entityManager->flush();

        return $this->redirectToRoute('list_product');
    }

    #[Route('/category', name: 'show_category')]
    public function show_category(CategoryRepository $categoryRepository): Response
    {
        $categories = $categoryRepository->findAll();
        // dd($categories);
        foreach ($categories as $category) {
            $totalProducts = count($category->getProduct()); 
            $category->total = $totalProducts;
        }
        return $this->render('category/category.html.twig', [
            'category' => $categories,
        ]);
    }

    #[Route('twig',name:'twig_template')]
    public function twig_concepts(ParameterBagInterface $params){
        $someParameter = $params->get('app.some_parameter');
        $env_parameter = $params->get('app.env_parameter');
        $databse_host = $this->getParameter('app.database_host');
        return $this->render('basics.html.twig',[
            'string_variable' =>  'this is string',
            'array_variable' => [['cars','bikes'],['mopads','trucks']],
            'config_para' => $someParameter,
            'env_parameter' => $env_parameter,
            'databse_host' => $databse_host
        ]);
    }
}
