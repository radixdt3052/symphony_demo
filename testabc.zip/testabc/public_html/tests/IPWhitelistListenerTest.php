<?php
namespace App\Tests;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class IPWhitelistListenerTest extends WebTestCase
{
    private array $whitelistedIPs = ['192.168.1.100', '10.0.0.1'];

    public function testAllowedIP()
    {
        $allowedIP = '192.168.1.100';

        $this->assertTrue(in_array($allowedIP, $this->whitelistedIPs));
    }

    public function testDeniedIP()
    {
        $deniedIP = '123.456.789.0';

        $this->assertFalse(in_array($deniedIP, $this->whitelistedIPs));
    }
}
