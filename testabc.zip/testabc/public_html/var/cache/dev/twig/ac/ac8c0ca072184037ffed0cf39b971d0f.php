<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* basics.html.twig */
class __TwigTemplate_372b467903a2d221aeccbec7e6ed1840 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "basics.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "basics.html.twig"));

        $this->parent = $this->loadTemplate("main.html.twig", "basics.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 4
        yield "<div class = 'site-content'>
    <div class=\"image-container\">
        <img src=\"";
        // line 6
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/symfony_black_02.png"), "html", null, true);
        yield "\" alt=\"Symfony!\">
    </div>
    <div>
        <p>Custom Global variable: <strong>";
        // line 9
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["set_custom_global_variable"]) || array_key_exists("set_custom_global_variable", $context) ? $context["set_custom_global_variable"] : (function () { throw new RuntimeError('Variable "set_custom_global_variable" does not exist.', 9, $this->source); })()), "html", null, true);
        yield "</strong></p>
    </div>
    <div>
        <p>String Variable: <strong>";
        // line 12
        yield (isset($context["string_variable"]) || array_key_exists("string_variable", $context) ? $context["string_variable"] : (function () { throw new RuntimeError('Variable "string_variable" does not exist.', 12, $this->source); })());
        yield "</strong></p>
    </div>
    <div>
        <p>Array Variables:
        ";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["array_variable"]) || array_key_exists("array_variable", $context) ? $context["array_variable"] : (function () { throw new RuntimeError('Variable "array_variable" does not exist.', 16, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["test_array"]) {
            // line 17
            yield "            <strong>";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join($context["test_array"], ", "), "html", null, true);
            yield "</strong>,
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['test_array'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        yield " </p>
    </div>
    <br>
    <div>";
        // line 21
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["config_para"]) || array_key_exists("config_para", $context) ? $context["config_para"] : (function () { throw new RuntimeError('Variable "config_para" does not exist.', 21, $this->source); })()), "html", null, true);
        yield "</div>
    <div>";
        // line 22
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["env_parameter"]) || array_key_exists("env_parameter", $context) ? $context["env_parameter"] : (function () { throw new RuntimeError('Variable "env_parameter" does not exist.', 22, $this->source); })()), "html", null, true);
        yield "</div>
    <div>";
        // line 23
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["databse_host"]) || array_key_exists("databse_host", $context) ? $context["databse_host"] : (function () { throw new RuntimeError('Variable "databse_host" does not exist.', 23, $this->source); })()), "html", null, true);
        yield "</div>
    <div> ";
        // line 24
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["direct_access_config"]) || array_key_exists("direct_access_config", $context) ? $context["direct_access_config"] : (function () { throw new RuntimeError('Variable "direct_access_config" does not exist.', 24, $this->source); })()), "html", null, true);
        yield " </div>    

    -----------------------------------------------------------------------------------
    ";
        // line 27
        yield Twig\Extension\CoreExtension::include($this->env, $context, "_fragment_basics.html.twig");
        yield "
    <br><br>    
    <div>
        <button class=\"color-button hover-button\" onclick=\"changeBackgroundColor()\">Hover here</button>
        <button onclick=\"refreshPage()\" class=\"remove-button\">Remove</button>
    </div>
</div>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "basics.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  128 => 27,  122 => 24,  118 => 23,  114 => 22,  110 => 21,  105 => 18,  96 => 17,  92 => 16,  85 => 12,  79 => 9,  73 => 6,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'main.html.twig' %}

{% block content %}
<div class = 'site-content'>
    <div class=\"image-container\">
        <img src=\"{{ asset('images/symfony_black_02.png') }}\" alt=\"Symfony!\">
    </div>
    <div>
        <p>Custom Global variable: <strong>{{ set_custom_global_variable }}</strong></p>
    </div>
    <div>
        <p>String Variable: <strong>{{ string_variable|raw }}</strong></p>
    </div>
    <div>
        <p>Array Variables:
        {% for test_array in array_variable %}
            <strong>{{ test_array|join(', ') }}</strong>,
        {% endfor %} </p>
    </div>
    <br>
    <div>{{ config_para }}</div>
    <div>{{ env_parameter }}</div>
    <div>{{ databse_host }}</div>
    <div> {{ direct_access_config }} </div>    

    -----------------------------------------------------------------------------------
    {{ include('_fragment_basics.html.twig') }}
    <br><br>    
    <div>
        <button class=\"color-button hover-button\" onclick=\"changeBackgroundColor()\">Hover here</button>
        <button onclick=\"refreshPage()\" class=\"remove-button\">Remove</button>
    </div>
</div>
{% endblock %}
", "basics.html.twig", "/home/GALAXYRADIXWEB/rahul.sonagara/web/testabc/public_html/templates/basics.html.twig");
    }
}
