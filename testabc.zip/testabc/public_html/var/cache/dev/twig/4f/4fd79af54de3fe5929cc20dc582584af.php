<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* category/category.html.twig */
class __TwigTemplate_6c7faff6550974dc82c61f400ef5e296 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "category/category.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "category/category.html.twig"));

        // line 1
        yield "<!DOCTYPE html>
<html>
<head>
    <title>Category</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }

        /* Style for Add Product button */
        .add-product-button {
            display: inline-block;
            margin-bottom: 10px; 
            padding-left: 104em;
            margin-bottom: 2em;
        }
        .add-product-button a {
            text-decoration: none;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border-radius: 4px;
           
        }
        .add-product-button a:hover {
            background-color: #0056b3;
            color: #fff;
        }
    </style>
</head>
<body>
    <h2><center>Category List</center></h2>

    
<a href=\"";
        // line 44
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("list_product");
        yield "\" class=\"btn btn-primary\">Back</a>
    <table>
        <thead>
            <tr>
                <th>Category Name</th>
                <th>Total product</th>
                
                
            </tr>
        </thead>
        <tbody>
            ";
        // line 55
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 55, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["categories"]) {
            // line 56
            yield "                <tr>
                    <td>";
            // line 57
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["categories"], "categoryName", [], "any", false, false, false, 57), "html", null, true);
            yield "</td>
               <td>";
            // line 58
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["categories"], "total", [], "any", false, false, false, 58), "html", null, true);
            yield "</td>
          
                 
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['categories'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 63
        yield "        </tbody>
    </table>
</body>
</html>";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "category/category.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  125 => 63,  114 => 58,  110 => 57,  107 => 56,  103 => 55,  89 => 44,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
<head>
    <title>Category</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }

        /* Style for Add Product button */
        .add-product-button {
            display: inline-block;
            margin-bottom: 10px; 
            padding-left: 104em;
            margin-bottom: 2em;
        }
        .add-product-button a {
            text-decoration: none;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border-radius: 4px;
           
        }
        .add-product-button a:hover {
            background-color: #0056b3;
            color: #fff;
        }
    </style>
</head>
<body>
    <h2><center>Category List</center></h2>

    
<a href=\"{{ path('list_product') }}\" class=\"btn btn-primary\">Back</a>
    <table>
        <thead>
            <tr>
                <th>Category Name</th>
                <th>Total product</th>
                
                
            </tr>
        </thead>
        <tbody>
            {% for categories in category %}
                <tr>
                    <td>{{ categories.categoryName }}</td>
               <td>{{ categories.total }}</td>
          
                 
                </tr>
            {% endfor %}
        </tbody>
    </table>
</body>
</html>", "category/category.html.twig", "/home/GALAXYRADIXWEB/rahul.sonagara/web/testabc/public_html/templates/category/category.html.twig");
    }
}
