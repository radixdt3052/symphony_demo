function changeBackgroundColor() {
    var randomColor = generateRandomColor();
    document.body.style.backgroundColor = randomColor;
}

function generateRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    // console.log(color)
    return color;
}

function refreshPage() {
    location.reload(); 
  }